"""""#oppgave b
x=1
y=2
z=x+y
myString=input("Skriv inn tekst: ")
myNum=int(input("Skriv inn et heltall: "))
print("Du skrev dette: ",myString, myNum, "og x+y=",z)
print(12*'na'+'bat'+'man')
#oppgave d
print('hello world')
#oppgave e"""
myNum=int(input("Skriv inn et heltall: "))
myNum2=int(input("Skriv inn et heltall til: "))
myString=input("Skriv inn tekst: ")
print("Du skrev dette: ",myString, myNum+myNum2)
#oppgave f
myNum=int(input("Skriv inn et heltall: "))
myNum2=int(input("Skriv inn et heltall til: "))
myString=input("Skriv inn tekst: ")
print("Du skrev dette: ",myString, myNum%myNum2)
#Dette tok sin tid å skrive
