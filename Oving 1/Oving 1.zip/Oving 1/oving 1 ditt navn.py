"""#oppgave a
x='Olav Milian'
print('Ditt navn er',x)
# oppgave b
x='Olav Milian'
y=19
print('Ditt navn er',x, 'og du er ',y,'år gammel.')
#oppgave c"""
x=input("Skriv inn ditt navn: ")
print("Hei",x,end="")
y=float(input(" hvor gammel er du: "))
z=float(input("Hvor gammel var du da du begynte å programere: "))
print('Da har du programert i',y-z,'år')
