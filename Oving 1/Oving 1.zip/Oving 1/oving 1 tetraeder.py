""""
oppgave a
h=3
a=3/6**0.5*h
A=3**0.5*a**2
rA=round(A,3)
print('Overflaten til et tetraeder med høyde',h,'er',A)
oppgave 2
h=3
a=3/6**0.5*h
A=3**0.5*a**2
rA=round(A,3)
V=2**0.5*a**3/12
rV=round(V,3)
print('Overflaten til et tetraeder med høyde',h,'er',A,'og volumet er',V)
oppgave c
"""
h=float(input('Skriv inn en høyde:'))
a=3/6**0.5*h
A=3**0.5*a**2
#rA=round(A,3)
V=2**0.5*a**3/12
#rV=round(V,3)

print('Overflaten til et tetraeder med høyde',h,'er',A,'og volumet er',V)