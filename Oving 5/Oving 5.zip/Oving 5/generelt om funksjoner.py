def gange(x,y):
    xy =x*y
    print(x, "*", y, "=", xy)
def argument(a):
    print(a)
def alltid_to():
    print(2)
print("#Oppgave a")

x = float(input("x = "))
y = float(input("y = "))
gange(x,y)

print("#Oppgave b")

a = input("Skriv noe: ")
argument(a)

print("#Oppgave c")

alltid_to()