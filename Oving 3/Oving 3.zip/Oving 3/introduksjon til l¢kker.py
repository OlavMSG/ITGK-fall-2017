print("#oppgave a")

for i in range(1, 6, 1):
    print(i)

print("#oppgave b")

x = 0
while x < 5:
    x += 1
    print(x)

print("#Oppgave c")

for j in range(15, 0, -1):
    print(j)

print("#Oppgave d")

y = 15
while y > 0 or y != 0:
    print(y)
    y -= 1